import torch
import torch.nn as nn
from einops import rearrange
from einops.layers.torch import Rearrange

class ConvBNAct(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, groups=1):
        super().__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, groups=groups, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.act = nn.SiLU()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class DynamicConv(nn.Module):
    def __init__(self, dim, kernel_size=7, reduction_ratio=4):
        super().__init__()
        self.kernel_size = kernel_size
        hidden_dim = max(dim // reduction_ratio, dim // 2)
        
        self.conv = nn.Conv2d(dim, dim, kernel_size, padding=kernel_size//2, groups=dim)
        self.dynamic_weight = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, hidden_dim, 1),
            nn.SiLU(),
            nn.Conv2d(hidden_dim, dim * 2, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        weight = self.dynamic_weight(x)
        weight1, weight2 = weight.chunk(2, dim=1)
        return self.conv(x) * weight1 + x * weight2

class FasterAttention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False):
        super().__init__()
        self.num_heads = num_heads
        self.scale = (dim // num_heads) ** -0.5

        self.qkv = nn.Conv2d(dim, dim * 3, 1, bias=qkv_bias)
        self.proj = nn.Conv2d(dim, dim, 1)

    def forward(self, x):
        B, C, H, W = x.shape
        qkv = self.qkv(x)
        q, k, v = qkv.chunk(3, dim=1)

        q = rearrange(q, 'b (h d) x y -> b h (x y) d', h=self.num_heads)
        k = rearrange(k, 'b (h d) x y -> b h d (x y)', h=self.num_heads)
        v = rearrange(v, 'b (h d) x y -> b h (x y) d', h=self.num_heads)

        attn = (q @ k) * self.scale
        attn = attn.softmax(dim=-1)

        x = attn @ v
        x = rearrange(x, 'b h (x y) d -> b (h d) x y', x=H, y=W)
        x = self.proj(x)
        return x

class FasterViTBlock(nn.Module):
    def __init__(self, dim, num_heads=8, expansion_factor=4):
        super().__init__()
        hidden_dim = dim * expansion_factor
        
        self.norm1 = nn.BatchNorm2d(dim)
        self.attn = FasterAttention(dim, num_heads)
        self.norm2 = nn.BatchNorm2d(dim)
        self.ffn = nn.Sequential(
            nn.Conv2d(dim, hidden_dim, 1),
            nn.BatchNorm2d(hidden_dim),
            nn.GELU(),
            DynamicConv(hidden_dim),
            nn.Conv2d(hidden_dim, dim, 1)
        )

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))
        return x

class FasterViT(nn.Module):
    def __init__(self, image_size=224, in_channels=3, num_classes=1000,
                 embed_dims=[64, 128, 256, 512], depths=[3, 3, 9, 3],
                 num_heads=[2, 4, 8, 16]):
        super().__init__()
        
        # Initial patch embedding
        self.patch_embed = ConvBNAct(in_channels, embed_dims[0], kernel_size=7, stride=4)
        
        # Transformer stages
        self.stages = nn.ModuleList([])
        for i in range(len(depths)):
            stage = nn.Sequential(
                *[FasterViTBlock(embed_dims[i], num_heads[i]) for _ in range(depths[i])]
            )
            self.stages.append(stage)
            if i < len(depths) - 1:
                self.stages.append(
                    ConvBNAct(embed_dims[i], embed_dims[i+1], kernel_size=2, stride=2)
                )

        # Classification head
        self.norm = nn.BatchNorm2d(embed_dims[-1])
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.head = nn.Linear(embed_dims[-1], num_classes)

    def forward(self, x):
        x = self.patch_embed(x)
        
        for stage in self.stages:
            x = stage(x)
            
        x = self.norm(x)
        x = self.pool(x).flatten(1)
        x = self.head(x)
        return x

def create_faster_vit(num_classes=1000, pretrained=False):
    model = FasterViT(
        image_size=224,
        in_channels=3,
        num_classes=num_classes,
        embed_dims=[64, 128, 256, 512],
        depths=[3, 3, 9, 3],
        num_heads=[2, 4, 8, 16]
    )
    return model 