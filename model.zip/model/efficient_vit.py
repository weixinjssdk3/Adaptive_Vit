import torch
import torch.nn as nn
from einops import rearrange
from einops.layers.torch import Rearrange

class LightFFN(nn.Module):
    def __init__(self, dim, expansion_factor=2, dropout=0.):
        super().__init__()
        hidden_dim = int(dim * expansion_factor)
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)

class GroupedSelfAttention(nn.Module):
    def __init__(self, dim, num_groups=8, qkv_bias=False, dropout=0.):
        super().__init__()
        self.num_groups = num_groups
        self.scale = (dim // num_groups) ** -0.5
        
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.proj = nn.Linear(dim, dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_groups, C // self.num_groups)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.dropout(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.dropout(x)
        return x

class EfficientTransformerBlock(nn.Module):
    def __init__(self, dim, num_groups=8, mlp_ratio=4., qkv_bias=False, dropout=0.):
        super().__init__()
        # First Light FFN
        self.light_ffn1 = LightFFN(dim, expansion_factor=mlp_ratio/2, dropout=dropout)
        self.norm1 = nn.LayerNorm(dim)
        
        # Grouped Self-Attention
        self.attn = GroupedSelfAttention(dim, num_groups=num_groups, qkv_bias=qkv_bias, dropout=dropout)
        self.norm2 = nn.LayerNorm(dim)
        
        # Second Light FFN
        self.light_ffn2 = LightFFN(dim, expansion_factor=mlp_ratio/2, dropout=dropout)
        self.norm3 = nn.LayerNorm(dim)

    def forward(self, x):
        # Sandwich layout
        x = x + self.light_ffn1(self.norm1(x))
        x = x + self.attn(self.norm2(x))
        x = x + self.light_ffn2(self.norm3(x))
        return x

class EfficientViT(nn.Module):
    def __init__(self, image_size=224, patch_size=16, in_channels=3, num_classes=1000,
                 embed_dim=384, depth=12, num_groups=8, mlp_ratio=4., qkv_bias=False,
                 dropout=0., emb_dropout=0.):
        super().__init__()
        
        # Image to Patch Embedding
        self.patch_embed = nn.Sequential(
            Rearrange('b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1=patch_size, p2=patch_size),
            nn.Linear(patch_size * patch_size * in_channels, embed_dim)
        )
        
        num_patches = (image_size // patch_size) ** 2
        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, embed_dim))
        self.cls_token = nn.Parameter(torch.randn(1, 1, embed_dim))
        self.dropout = nn.Dropout(emb_dropout)

        # Transformer Blocks
        self.blocks = nn.ModuleList([
            EfficientTransformerBlock(
                dim=embed_dim,
                num_groups=num_groups,
                mlp_ratio=mlp_ratio,
                qkv_bias=qkv_bias,
                dropout=dropout
            )
            for _ in range(depth)
        ])

        self.norm = nn.LayerNorm(embed_dim)
        self.head = nn.Linear(embed_dim, num_classes)

    def forward(self, img):
        x = self.patch_embed(img)
        b, n, _ = x.shape

        cls_tokens = self.cls_token.expand(b, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)

        for block in self.blocks:
            x = block(x)

        x = self.norm(x)
        x = x[:, 0]  # Take cls token
        x = self.head(x)
        return x

def create_efficient_vit(num_classes=1000, pretrained=False):
    model = EfficientViT(
        image_size=224,
        patch_size=16,
        in_channels=3,
        num_classes=num_classes,
        embed_dim=384,
        depth=12,
        num_groups=8,
        mlp_ratio=4.,
        dropout=0.1,
        emb_dropout=0.1
    )
    return model 