import sys
sys.path.append(r"D:\Codes\PyTorch_nn")
from model.resnet import resnet18, resnet50, resnet101
from model.vit import vit_base_patch16_224
from model.densenet import densenet121, densenet169, densenet201
from model.adaptive_vit import create_adaptive_vit
from model.MedicalAdaptive_vit import medical_adaptive_vit
from model.medical_vit import create_medical_vit, create_hybrid_medical_vit, create_efficient_medical_vit
from model.efficient_vit import create_efficient_vit
from model.mobile_vit_v3 import create_mobile_vit_v3
from model.fast_vit import create_fast_vit
from model.faster_vit import create_faster_vit
from model.swin_transformer import create_swin_transformer
from model.swin_transformer_timm import create_swin_transformer_small, create_swin_transformer_base
from model.MultimodalAdaptiveViT import create_multimodal_adaptive_vit
from model.standard_vit import create_standard_vit
from model.deit import create_deit
from model.dynamic_vit import create_dynamic_vit_base
from model.lvt import create_lvt_medium
from model.ppt import create_ppt_base
from model.pvt import create_pvt_medium, create_pvt_large

model_dict = {
    'resnet18': resnet18,
    'resnet50': resnet50,
    'resnet101': resnet101,
    'vit': vit_base_patch16_224,
    'densenet121': densenet121,
    'densenet169': densenet169,
    'densenet201': densenet201,
    'adaptive_vit': create_adaptive_vit,
    'medical_adaptive_vit': medical_adaptive_vit,
    'medical_vit': create_medical_vit,
    'hybrid_medical_vit': create_hybrid_medical_vit,
    'efficient_vit': create_efficient_medical_vit,
    'efficient_vit_2022': create_efficient_vit,
    'mobile_vit_v3': create_mobile_vit_v3,
    'fast_vit': create_fast_vit,
    'faster_vit': create_faster_vit,
    'swin': create_swin_transformer,
    'swin_small': create_swin_transformer_small,
    'swin_base': create_swin_transformer_base,
    'multimodal_adaptive_vit': create_multimodal_adaptive_vit,
    'standard_vit': create_standard_vit,
    'deit': create_deit,
    'dynamic_vit': create_dynamic_vit_base,
    'lvt_medium': create_lvt_medium,
    'ppt_base': create_ppt_base,
    'pvt_medium': create_pvt_medium,
    'pvt_large': create_pvt_large
}

def create_model(model_name, num_classes):   
    return model_dict[model_name](num_classes = num_classes)