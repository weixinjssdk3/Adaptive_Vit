import torch
import torch.nn as nn
from einops import rearrange
from einops.layers.torch import Rearrange

class ConvBNAct(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, groups=1):
        super().__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, groups=groups, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.act = nn.SiLU()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class MobileNetBlock(nn.Module):
    def __init__(self, inp, exp, out, kernel_size, stride):
        super().__init__()
        self.stride = stride
        hidden_dim = exp

        layers = []
        if hidden_dim != inp:
            layers.append(ConvBNAct(inp, hidden_dim, kernel_size=1))
        
        layers.extend([
            ConvBNAct(hidden_dim, hidden_dim, kernel_size, stride, groups=hidden_dim),
            nn.Conv2d(hidden_dim, out, 1, 1, 0, bias=False),
            nn.BatchNorm2d(out)
        ])
        
        self.conv = nn.Sequential(*layers)
        self.use_res_connect = stride == 1 and inp == out

    def forward(self, x):
        if self.use_res_connect:
            return x + self.conv(x)
        return self.conv(x)

class TransformerBlock(nn.Module):
    def __init__(self, dim, heads=8, dim_head=32, mlp_ratio=4, dropout=0.):
        super().__init__()
        mlp_dim = int(dim * mlp_ratio)

        # 在MobileViTBlock中，输入到Transformer的维度是patch_size*patch_size*dim
        # 因此这里需要使用正确的维度初始化LayerNorm和其他层
        self.dim = dim
        self.heads = heads
        self.dim_head = dim_head
        self.norm1 = None  # 将在forward中动态创建
        self.attn = None   # 将在forward中动态创建
        self.norm2 = None  # 将在forward中动态创建
        self.mlp_ratio = mlp_ratio
        self.dropout = dropout
        self.mlp = None    # 将在forward中动态创建

    def _init_layers(self, actual_dim, device):
        # 动态初始化层，使用实际输入的维度，并确保在正确的设备上
        mlp_dim = int(actual_dim * self.mlp_ratio)
        self.norm1 = nn.LayerNorm(actual_dim).to(device)
        self.attn = nn.MultiheadAttention(actual_dim, self.heads, dropout=self.dropout, batch_first=True).to(device)
        self.norm2 = nn.LayerNorm(actual_dim).to(device)
        self.mlp = nn.Sequential(
            nn.Linear(actual_dim, mlp_dim),
            nn.GELU(),
            nn.Dropout(self.dropout),
            nn.Linear(mlp_dim, actual_dim),
            nn.Dropout(self.dropout)
        ).to(device)

    def forward(self, x):
        # 获取实际输入的维度并初始化层（如果尚未初始化）
        B, N, C = x.shape
        device = x.device  # 获取输入张量的设备
        
        if self.norm1 is None or self.norm1.normalized_shape[0] != C:
            self._init_layers(C, device)
        
        # 确保所有层都在正确的设备上
        if not all(p.device == device for p in self.parameters()):
            self.to(device)
            
        # 使用标准的Transformer前向传播
        x_norm = self.norm1(x)
        x = x + self.attn(x_norm, x_norm, x_norm)[0]
        x = x + self.mlp(self.norm2(x))
        return x

class MobileViTBlock(nn.Module):
    def __init__(self, in_channels, dim, kernel_size, patch_size, depth):
        super().__init__()
        self.ph, self.pw = patch_size, patch_size
        self.dim = dim  # 保存dim值以便在forward中使用

        self.conv1 = ConvBNAct(in_channels, in_channels, kernel_size)
        self.conv2 = nn.Conv2d(in_channels, dim, 1)

        # 使用ModuleList，每个TransformerBlock使用正确的维度
        self.transformer_blocks = nn.ModuleList([
            TransformerBlock(dim=dim) for _ in range(depth)
        ])

        self.conv3 = nn.Conv2d(dim, in_channels, 1)
        self.conv4 = ConvBNAct(2 * in_channels, in_channels, kernel_size)

    def forward(self, x):
        y = x.clone()

        # Local representation
        x = self.conv1(x)
        x = self.conv2(x)

        # Global representation
        b, c, h, w = x.shape
        
        # 计算能被patch_size整除的新尺寸
        new_h = (h // self.ph) * self.ph
        new_w = (w // self.pw) * self.pw
        
        # 确保新尺寸至少为patch_size
        new_h = max(new_h, self.ph)
        new_w = max(new_w, self.pw)
        
        if new_h != h or new_w != w:
            # 如果尺寸不能被patch_size整除，使用自适应池化调整尺寸
            x = nn.functional.adaptive_avg_pool2d(x, (new_h, new_w))
        
        # 计算每个维度上的patch数量
        h_patches = new_h // self.ph
        w_patches = new_w // self.pw
        
        # 使用更安全的张量重排方法
        # 从 [B, C, H, W] 到 [B, (H//ph)*(W//pw), ph*pw*C]
        x = x.reshape(b, c, h_patches, self.ph, w_patches, self.pw)
        x = x.permute(0, 2, 4, 3, 5, 1).contiguous()
        x = x.reshape(b, h_patches * w_patches, self.ph * self.pw * c)
        
        # 打印实际维度，帮助调试
        # print(f"Transformer input shape: {x.shape}")
        
        # 手动应用每个TransformerBlock
        for block in self.transformer_blocks:
            x = block(x)
        
        # 从 [B, (H//ph)*(W//pw), ph*pw*C] 回到 [B, C, H, W]
        x = x.reshape(b, h_patches, w_patches, self.ph, self.pw, c)
        x = x.permute(0, 5, 1, 3, 2, 4).contiguous()
        x = x.reshape(b, c, h_patches * self.ph, w_patches * self.pw)
        
        # 如果之前调整了尺寸，现在恢复到原始尺寸
        if new_h != h or new_w != w:
            x = nn.functional.interpolate(x, size=(h, w), mode='bilinear', align_corners=False)

        # Fusion
        x = self.conv3(x)
        x = torch.cat((x, y), 1)
        x = self.conv4(x)
        return x

class MobileViTv3(nn.Module):
    def __init__(self, image_size=224, in_channels=3, num_classes=1000, dims=[96, 120, 144], 
                 channels=[16, 32, 48, 64, 80], expansion=4):
        super().__init__()
        
        # Initial conv layer
        self.conv1 = ConvBNAct(in_channels, channels[0], kernel_size=3, stride=2)

        # MobileNet stages
        self.mv2 = nn.ModuleList([])
        self.mv2.append(MobileNetBlock(channels[0], channels[0]*expansion, channels[1], 3, 2))
        self.mv2.append(MobileNetBlock(channels[1], channels[1]*expansion, channels[2], 3, 2))
        self.mv2.append(MobileNetBlock(channels[2], channels[2]*expansion, channels[3], 3, 2))
        self.mv2.append(MobileNetBlock(channels[3], channels[3]*expansion, channels[4], 3, 2))

        # MobileViT stages
        self.mvit = nn.ModuleList([])
        self.mvit.append(MobileViTBlock(channels[2], dims[0], 3, 2, 2))
        self.mvit.append(MobileViTBlock(channels[3], dims[1], 3, 2, 4))
        self.mvit.append(MobileViTBlock(channels[4], dims[2], 3, 2, 3))

        # Classification head
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Sequential(
            nn.Linear(channels[-1], num_classes)
        )

    def forward(self, x):
        x = self.conv1(x)
        
        # MobileNet stages
        x = self.mv2[0](x)
        x = self.mv2[1](x)
        x = self.mvit[0](x)
        x = self.mv2[2](x)
        x = self.mvit[1](x)
        x = self.mv2[3](x)
        x = self.mvit[2](x)

        # Classification
        x = self.pool(x).flatten(1)
        x = self.classifier(x)
        return x

def create_mobile_vit_v3(num_classes=1000, pretrained=False):
    model = MobileViTv3(
        image_size=224,
        in_channels=3,
        num_classes=num_classes,
        dims=[96, 120, 144],
        channels=[16, 32, 48, 64, 80]
    )
    return model