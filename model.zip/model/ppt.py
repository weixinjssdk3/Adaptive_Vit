from torch import nn
import timm
import torch
import torch.nn.functional as F

class PPTBase(nn.Module):
    """
    Pyramid Pooling Transformer Base (PPT-B)
    结合金字塔池化和Transformer架构的视觉模型
    
    Args:
        model_name (str): timm中预训练模型的名称
        num_classes (int): 分类任务的类别数
        pretrained (bool): 是否使用预训练权重
        pool_scales (tuple): 金字塔池化的尺度列表
    """
    def __init__(
        self,
        model_name: str = "vit_base_patch16_224",
        num_classes: int = 4,
        pretrained: bool = True,
        pool_scales: tuple = (1, 2, 3, 6)
    ):
        super().__init__()
        
        # 加载预训练的ViT模型作为主干网络
        self.backbone = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=0,  # 移除分类头
        )
        
        # 获取特征维度
        self.feature_dim = self.backbone.num_features
        
        # 计算patch的大小和数量
        self.patch_size = int(self.backbone.patch_embed.num_patches ** 0.5)
        
        # 金字塔池化模块
        self.ppm = PyramidPoolingModule(
            in_dim=self.feature_dim,
            reduction_dim=self.feature_dim // 4,
            scales=pool_scales
        )
        
        # 计算PPM输出维度 (cls_token + ppm特征)
        # cls_token维度为self.feature_dim
        # ppm特征维度为原始特征 + 每个尺度的降维特征
        self.ppm_features_dim = self.feature_dim + len(pool_scales) * (self.feature_dim // 4)
        self.ppm_out_dim = self.feature_dim + self.ppm_features_dim
        
        # 分类头 - 使用正确的输入维度
        self.head = nn.Sequential(
            nn.LayerNorm(self.ppm_out_dim),
            nn.Linear(self.ppm_out_dim, self.ppm_out_dim // 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(self.ppm_out_dim // 2, num_classes)
        )
    
    def forward_features(self, x):
        """特征提取"""
        # 通过backbone提取特征
        x = self.backbone.patch_embed(x)
        cls_token = self.backbone.cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        x = self.backbone.pos_drop(x + self.backbone.pos_embed)
        
        # 通过transformer块
        for blk in self.backbone.blocks:
            x = blk(x)
        
        x = self.backbone.norm(x)
        
        # 提取cls token和patch tokens
        cls_features = x[:, 0]  # [B, C]
        patch_features = x[:, 1:]  # [B, N, C]
        
        # 计算特征图的空间尺寸
        # 注意：这里需要确保patch_features的空间尺寸是正确的
        # 对于ViT模型，patch_features的形状应该是[B, N, C]，其中N是patch的数量
        # 我们需要将其重塑为[B, H, W, C]，然后转置为[B, C, H, W]用于PPM
        
        # 获取patch数量并计算特征图尺寸
        num_patches = patch_features.shape[1]
        h = w = int(num_patches ** 0.5)  # 假设特征图是正方形的
        
        # 重塑patch tokens以用于金字塔池化
        patch_features = patch_features.reshape(patch_features.shape[0], h, w, -1)
        patch_features = patch_features.permute(0, 3, 1, 2)  # [B, C, H, W]
        
        # 应用金字塔池化
        ppm_features = self.ppm(patch_features)
        
        # 全局平均池化以减少特征维度
        # 这样可以确保无论输入图像大小如何，输出特征维度都是固定的
        pooled_features = F.adaptive_avg_pool2d(ppm_features, 1).squeeze(-1).squeeze(-1)  # [B, C]
        
        # 确保pooled_features的维度与预期的ppm_features_dim匹配
        if pooled_features.size(1) != self.ppm_features_dim:
            print(f"警告: PPM特征维度 {pooled_features.size(1)} 与预期 {self.ppm_features_dim} 不匹配")
            # 如果维度不匹配，使用线性投影调整维度
            if not hasattr(self, 'dim_adapter'):
                self.dim_adapter = nn.Linear(pooled_features.size(1), self.ppm_features_dim).to(pooled_features.device)
            pooled_features = self.dim_adapter(pooled_features)
        
        # 结合cls token和金字塔池化特征
        combined_features = torch.cat([cls_features, pooled_features], dim=1)  # [B, feature_dim + ppm_features_dim]

        
        return combined_features
    
    def forward(self, x):
        """前向传播"""
        # 检查批次大小，如果为1且处于训练模式，则临时切换到评估模式
        batch_size = x.size(0)
        was_training = self.training
        if batch_size == 1 and was_training:
            # 临时切换到评估模式以避免BatchNorm错误
            self.eval()
            
        features = self.forward_features(x)
        output = self.head(features)
        
        # 如果之前临时切换了模式，恢复原来的模式
        if batch_size == 1 and was_training:
            self.train()
            
        return output


class PyramidPoolingModule(nn.Module):
    """
    金字塔池化模块 (PPM)
    在不同尺度上捕获上下文信息
    
    Args:
        in_dim (int): 输入特征维度
        reduction_dim (int): 降维后的特征维度
        scales (tuple): 池化尺度列表
    """
    def __init__(self, in_dim, reduction_dim, scales=(1, 2, 3, 6)):
        super().__init__()
        
        self.features = []
        for scale in scales:
            self.features.append(
                nn.Sequential(
                    nn.AdaptiveAvgPool2d(scale),
                    nn.Conv2d(in_dim, reduction_dim, kernel_size=1, bias=False),
                    nn.GroupNorm(num_groups=1, num_channels=reduction_dim),  # 替换BatchNorm为GroupNorm
                    nn.ReLU(inplace=True)
                )
            )
        self.features = nn.ModuleList(self.features)
        
        # 保存输出维度信息，用于后续维度检查
        self.out_channels = in_dim + len(scales) * reduction_dim
        self.scales = scales
        self.reduction_dim = reduction_dim
    
    def forward(self, x):
        x_size = x.size()
        out = [x]
        
        for f in self.features:
            # 应用池化和卷积
            pooled = f(x)
            # 上采样到原始大小
            upsampled = F.interpolate(
                pooled, 
                size=(x_size[2], x_size[3]), 
                mode='bilinear', 
                align_corners=True
            )
            out.append(upsampled)
        
        # 沿通道维度连接所有特征
        result = torch.cat(out, 1)
        
        # 确保输出维度正确
        expected_channels = self.out_channels
        if result.size(1) != expected_channels:
            print(f"警告: PPM输出通道数 {result.size(1)} 与预期 {expected_channels} 不匹配")
            # 如果通道数不匹配，进行裁剪或填充
            if result.size(1) > expected_channels:
                result = result[:, :expected_channels, :, :]
        
        return result


def create_ppt_base(
    model_name: str = "vit_base_patch16_224",
    num_classes: int = 4,
    pretrained: bool = True,
    **kwargs
):
    """创建PPT-B模型的工厂函数"""
    model = PPTBase(
        model_name=model_name,
        num_classes=num_classes,
        pretrained=pretrained,
        **kwargs
    )
    return model