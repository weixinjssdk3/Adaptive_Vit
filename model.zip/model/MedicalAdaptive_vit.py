import timm
import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.vision_transformer import VisionTransformer
from timm.models.layers import DropPath, trunc_normal_


class StochasticDepth(nn.Module):
    """
    随机深度正则化模块（用于分类头）
    功能：训练时随机丢弃部分网络层，增强模型泛化能力
    论文参考：Deep Networks with Stochastic Depth (ECCV 2016)
    """

    def __init__(self, p=0.5):
        super().__init__()
        self.p = p  # 丢弃概率

    def forward(self, x):
        if not self.training or self.p == 0.:
            return x
        survival_rate = 1. - self.p
        mask = torch.empty(x.shape[0], 1, device=x.device).bernoulli_(survival_rate)
        return x * mask / survival_rate


class EnhancedComplexityEstimator(nn.Module):
    """
    增强型医学图像复杂度估计器
    结构特点：
    - 5x5卷积核捕获解剖结构
    - 多阶段特征压缩
    - 批归一化稳定训练
    - 深度全连接层增强非线性
    """

    def __init__(self, in_channels=3):
        super().__init__()
        # 特征提取主干
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, 32, kernel_size=5, padding=2),  # 保持空间分辨率
            nn.BatchNorm2d(32),
            nn.GELU(),  # 比ReLU更平滑的激活函数
            nn.MaxPool2d(2),  # 下采样到112x112

            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.GELU(),
            nn.AdaptiveAvgPool2d(1)  # 全局特征聚合
        )

        # 复杂度回归头
        self.fc = nn.Sequential(
            nn.Linear(64, 32),
            nn.Dropout(0.3),  # 防止过拟合
            nn.LayerNorm(32),  # 稳定特征分布
            nn.GELU(),
            nn.Linear(32, 1)  # 输出复杂度评分
        )

        # 初始化权重
        self._init_weights()

    def _init_weights(self):
        """专用权重初始化策略"""
        nn.init.xavier_uniform_(self.fc[-1].weight)
        nn.init.constant_(self.fc[-1].bias, 0.5)  # 初始偏向中等复杂度

    def forward(self, x):
        # 输入形状: (B, 3, 224, 224)
        x = self.conv(x)  # -> (B, 64, 1, 1)
        x = x.flatten(1)  # -> (B, 64)
        return torch.sigmoid(self.fc(x))  # 输出范围[0,1]


class MedicalAdaptiveViT(nn.Module):
    """
    医学专用自适应Vision Transformer
    核心改进：
    1. 动态深度调整机制
    2. 增强型复杂度估计器
    3. 医学优化分类头
    4. 分层随机深度正则化
    """

    def __init__(self,
                 model_name='vit_base_patch16_224',
                 num_classes=4,
                 pretrained=True,
                 min_layers=8,  # 最低层数保证基础特征提取
                 adaptation_threshold=0.3,  # 复杂度阈值
                 drop_path_rate=0.1):  # 主干网络随机深度
        super().__init__()

        # 加载预训练ViT主干
        self.backbone = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=num_classes,
            drop_path_rate=drop_path_rate  # 添加随机深度正则
        )

        # 医学图像复杂度估计器
        self.complexity_estimator = EnhancedComplexityEstimator()

        # 动态调整参数配置
        self.num_layers = len(self.backbone.blocks)  # ViT总层数（通常12层）
        self.min_layers = max(min_layers, 4)  # 确保最低4层
        self.adaptation_threshold = adaptation_threshold

        # 改进医学分类头
        in_features = self.backbone.head.in_features
        self.backbone.head = nn.Sequential(
            nn.LayerNorm(in_features),  # 先归一化
            nn.Dropout(0.3),  # 高丢弃率防止过拟合
            nn.Linear(in_features, in_features),  # 保持维度
            nn.GELU(),  # 平滑非线性
            StochasticDepth(p=0.1),  # 随机深度正则
            nn.Linear(in_features, num_classes)  # 最终分类层
        )

        # 权重初始化
        self._init_weights()

    def _init_weights(self):
        """医学专用权重初始化"""
        # 分类头初始化
        trunc_normal_(self.backbone.head[2].weight, std=0.02)  # 匹配预训练分布
        nn.init.constant_(self.backbone.head[2].bias, 0)

    def get_adaptive_layers(self, complexity_score):
        """
        动态层数调整策略
        参数：
            complexity_score (torch.Tensor): 来自估计器的复杂度评分
        返回：
            int: 实际使用的Transformer层数
        """
        base_layers = max(
            self.min_layers,
            int(self.num_layers * complexity_score)
        )

        # 医学图像特殊处理
        if complexity_score < 0.3:  # 简单样本补偿机制
            return min(base_layers + 2, self.num_layers)
        elif complexity_score > 0.7:  # 关键样本强制全层
            return self.num_layers
        else:
            return base_layers

    def forward_features(self, x):
        """
        自适应特征提取流程
        返回：
            tuple: (分类特征, 复杂度评分)
        """
        # 估计图像复杂度
        complexity = self.complexity_estimator(x)

        # 动态确定层数
        num_layers = self.get_adaptive_layers(complexity.mean())

        # ViT特征提取流程
        x = self.backbone.patch_embed(x)  # 分块嵌入
        cls_token = self.backbone.cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        x = self.backbone.pos_drop(x + self.backbone.pos_embed)

        # 动态层选择
        for i in range(num_layers):
            x = self.backbone.blocks[i](x)

        x = self.backbone.norm(x)
        return x[:, 0], complexity  # 返回CLS token和复杂度

    def forward(self, x):
        """
        完整前向传播
        训练模式返回： (logits, complexity_scores)
        推理模式返回： logits
        """
        features, complexity = self.forward_features(x)
        logits = self.backbone.head(features)
        return (logits, complexity) if self.training else logits

def medical_adaptive_vit(
    model_name: str = "vit_base_patch16_224",
    num_classes: int = 4,
    pretrained: bool = True,
    **kwargs
) -> MedicalAdaptiveViT:
    """
    医学自适应ViT工厂函数
    参数：
        model_name: 预训练模型名称（默认为vit_base）
        num_classes: 分类类别数
        pretrained: 是否加载预训练权重
        **kwargs: 传递给MedicalAdaptiveViT的其他参数
    返回：
        配置好的MedicalAdaptiveViT实例
    """
    return MedicalAdaptiveViT(
        model_name=model_name,
        num_classes=num_classes,
        pretrained=pretrained,
        **kwargs
    )