import torch
import torch.nn as nn
import timm

class PVTMedium(nn.Module):
    """Pyramid Vision Transformer Medium (PVT-M)
    
    PVT是一种层次化的Vision Transformer，通过逐步减小特征图尺寸和增加通道数来构建层次化表示。
    PVT-Medium是其中等规模的版本，适合大多数视觉任务。
    """
    def __init__(self, num_classes=1000, pretrained=True, drop_rate=0.0, drop_path_rate=0.1):
        super().__init__()
        # 使用timm库加载预训练的PVT-Medium模型
        self.model = timm.create_model(
            'pvt_v2_b3', 
            pretrained=pretrained, 
            num_classes=num_classes,
            # img_size参数不被PyramidVisionTransformerV2支持，移除
            drop_rate=drop_rate,
            drop_path_rate=drop_path_rate
        )
        
        # 获取模型的特征维度
        self.embed_dim = self.model.head.in_features
        
        # 替换分类头以适应指定的类别数
        self.model.head = nn.Linear(self.embed_dim, num_classes) if num_classes > 0 else nn.Identity()
    
    def forward(self, x):
        return self.model(x)

class PVTLarge(nn.Module):
    """Pyramid Vision Transformer Large (PVT-L)
    
    PVT-Large是PVT的大型版本，具有更多的参数和更强的表示能力，适合复杂的视觉任务。
    """
    def __init__(self, num_classes=1000, pretrained=True, drop_rate=0.0, drop_path_rate=0.1):
        super().__init__()
        # 使用timm库加载预训练的PVT-Large模型
        self.model = timm.create_model(
            'pvt_v2_b4', 
            pretrained=pretrained, 
            num_classes=num_classes,
            # img_size参数不被PyramidVisionTransformerV2支持，移除
            drop_rate=drop_rate,
            drop_path_rate=drop_path_rate
        )
        
        # 获取模型的特征维度
        self.embed_dim = self.model.head.in_features
        
        # 替换分类头以适应指定的类别数
        self.model.head = nn.Linear(self.embed_dim, num_classes) if num_classes > 0 else nn.Identity()
    
    def forward(self, x):
        return self.model(x)

def create_pvt_medium(num_classes=1000, pretrained=True):
    """创建PVT-Medium模型的工厂函数"""
    return PVTMedium(num_classes=num_classes, pretrained=pretrained)

def create_pvt_large(num_classes=1000, pretrained=True):
    """创建PVT-Large模型的工厂函数"""
    return PVTLarge(num_classes=num_classes, pretrained=pretrained)