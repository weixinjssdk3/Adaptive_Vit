import torch
import torch.nn as nn
import timm
from functools import partial

class LVTMedium(nn.Module):
    """
    Light Vision Transformer-Medium (LVT-M) 模型
    一种轻量级的Vision Transformer变体，使用timm库加载预训练模型
    """
    def __init__(self, num_classes=1000, pretrained=True, img_size=224, drop_rate=0.0, drop_path_rate=0.1):
        super().__init__()
        # 使用timm库加载预训练的LVT-Medium模型
        # 注意：使用levit_384作为LVT-Medium的基础模型，因为它是一种轻量级的Vision Transformer
        self.model = timm.create_model(
            'levit_384', 
            pretrained=pretrained, 
            num_classes=0,  # 设置为0以获取特征而不是分类结果
            img_size=img_size,
            drop_rate=drop_rate,
            drop_path_rate=drop_path_rate
        )
        
        # 获取模型的特征维度 - levit模型使用NormLinear作为分类头，没有in_features属性
        # 需要从模型结构中获取正确的特征维度
        
        # 对于levit模型，特征维度通常是384（对应levit_384）
        # 直接从模型名称中提取特征维度
        self.embed_dim = 384  # 默认值
        
        # 检查模型的head类型，并获取正确的特征维度
        if hasattr(self.model, 'head') and hasattr(self.model.head, 'weight'):
            # 从权重矩阵的形状获取特征维度
            self.embed_dim = self.model.head.weight.shape[1]
        
        # 添加一个维度调整层，将768维特征转换为384维
        self.dim_adapter = nn.Linear(768, self.embed_dim)
        
        # 添加分类头
        self.classifier = nn.Linear(self.embed_dim, num_classes) if num_classes > 0 else nn.Identity()
        
    def forward(self, x):
        # 前向传播
        x = self.model(x)
        
        # 检查特征维度并进行调整
        if x.size(1) != self.embed_dim:
            x = self.dim_adapter(x)
            
        # 应用分类头
        x = self.classifier(x)
        
        # 返回单个输出，与train5.py中的处理兼容
        return x

def create_lvt_medium(num_classes=1000, pretrained=True):
    """
    创建LVT-Medium模型的工厂函数
    
    Args:
        num_classes (int): 分类类别数
        pretrained (bool): 是否使用预训练权重
        
    Returns:
        LVTMedium: 配置好的LVT-Medium模型实例
    """
    model = LVTMedium(
        num_classes=num_classes,
        pretrained=pretrained,
        img_size=224,  # 固定输入大小为224x224，与train5.py中的设置一致
        drop_rate=0.0,
        drop_path_rate=0.1
    )
    return model