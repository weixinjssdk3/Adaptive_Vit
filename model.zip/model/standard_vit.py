from torch import nn
import timm
import torch

class StandardVisionTransformer(nn.Module):
    """
    标准版本的Vision Transformer (ViT)，基于timm库中的预训练模型。
    
    Args:
        model_name (str): timm库中预训练ViT模型的名称，默认为'vit_base_patch16_224'
        num_classes (int): 分类任务的类别数
        pretrained (bool): 是否使用预训练权重
        freeze_backbone (bool): 是否冻结主干网络参数
    """
    def __init__(
        self,
        model_name: str = "vit_base_patch16_224",
        num_classes: int = 1000,
        pretrained: bool = True,
        freeze_backbone: bool = False
    ):
        super().__init__()
        
        # 加载预训练的ViT模型
        self.model = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=num_classes
        )
        
        # 获取模型的特征维度
        self.feature_dim = self.model.num_features
        
        # 是否冻结主干网络
        if freeze_backbone:
            # 冻结除了分类头以外的所有参数
            for name, param in self.model.named_parameters():
                if 'head' not in name:
                    param.requires_grad = False
    
    def forward(self, x):
        """
        前向传播
        
        Args:
            x: 输入图像，形状为 [B, C, H, W]
        
        Returns:
            模型输出的logits
        """
        return self.model(x)


def create_standard_vit(
    model_name: str = "vit_base_patch16_224",
    num_classes: int = 1000,
    pretrained: bool = True,
    **kwargs
):
    """
    创建标准ViT模型的工厂函数
    
    Args:
        model_name: timm库中预训练ViT模型的名称
        num_classes: 分类任务的类别数
        pretrained: 是否使用预训练权重
        **kwargs: 其他参数
    
    Returns:
        StandardVisionTransformer实例
    """
    model = StandardVisionTransformer(
        model_name=model_name,
        num_classes=num_classes,
        pretrained=pretrained,
        **kwargs
    )
    return model