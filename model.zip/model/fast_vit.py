import torch
import torch.nn as nn
from einops import rearrange
from einops.layers.torch import Rearrange

class ConvBNAct(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, groups=1):
        super().__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, groups=groups, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.act = nn.SiLU()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class RepLKBlock(nn.Module):
    def __init__(self, dim, kernel_size=7):
        super().__init__()
        padding = kernel_size // 2
        self.conv1 = nn.Conv2d(dim, dim, kernel_size, padding=padding, groups=dim)
        self.conv2 = nn.Conv2d(dim, dim, 1)
        self.bn = nn.BatchNorm2d(dim)
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(self.bn(self.conv2(self.conv1(x))))

class FastAttention(nn.Module):
    def __init__(self, dim, heads=8, reduction_ratio=8):
        super().__init__()
        self.heads = heads
        self.dim = dim
        self.dim_head = dim // heads
        self.scale = self.dim_head ** -0.5
        
        # 空间降维的输出大小
        self.sr_ratio = reduction_ratio
        
        self.to_qkv = nn.Conv2d(dim, dim * 3, 1, bias=False)
        self.to_out = nn.Conv2d(dim, dim, 1)

        # 空间降维
        self.sr = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=reduction_ratio, stride=reduction_ratio),
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        b, c, h, w = x.shape
        
        # 获取 q, k, v
        q, k, v = self.to_qkv(x).chunk(3, dim=1)
        
        # 处理 q
        q = rearrange(q, 'b (head d) h w -> b head (h w) d', head=self.heads)
        
        # 对 k, v 进行空间降维
        k = self.sr(k)
        v = self.sr(v)
        
        # 重排 k, v
        k = rearrange(k, 'b (head d) h w -> b head (h w) d', head=self.heads)
        v = rearrange(v, 'b (head d) h w -> b head (h w) d', head=self.heads)
        
        # 注意力计算
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        
        # 计算输出
        out = (attn @ v)
        out = rearrange(out, 'b head (h w) d -> b (head d) h w', head=self.heads, h=h, w=w)
        
        return self.to_out(out)

class FastViTBlock(nn.Module):
    def __init__(self, dim, num_heads, reduction_ratio=8):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = FastAttention(dim, num_heads, reduction_ratio)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4),
            nn.GELU(),
            nn.Linear(dim * 4, dim)
        )

    def forward(self, x):
        B, C, H, W = x.shape
        x = x.permute(0, 2, 3, 1)
        
        x_norm = self.norm1(x)
        x_norm = x_norm.permute(0, 3, 1, 2)
        x = x.permute(0, 3, 1, 2) + self.attn(x_norm)
        
        x = x.permute(0, 2, 3, 1)
        x_norm = self.norm2(x)
        x = x + self.ffn(x_norm)
        x = x.permute(0, 3, 1, 2)
        
        return x

class FastViT(nn.Module):
    def __init__(self, image_size=224, in_channels=3, num_classes=1000,
                 embed_dims=[64, 128, 256, 512], depths=[2, 2, 6, 2],
                 num_heads=[2, 4, 8, 16], reduction_ratio=8):
        super().__init__()
        
        # Patch embedding
        self.patch_embed = ConvBNAct(in_channels, embed_dims[0], kernel_size=7, stride=4)
        
        # Transformer stages
        self.stages = nn.ModuleList([])
        for i in range(len(depths)):
            stage = nn.Sequential(
                *[FastViTBlock(embed_dims[i], num_heads[i], reduction_ratio) 
                  for _ in range(depths[i])]
            )
            self.stages.append(stage)
            if i < len(depths) - 1:
                self.stages.append(
                    ConvBNAct(embed_dims[i], embed_dims[i+1], kernel_size=2, stride=2)
                )

        # Classification head
        self.norm = nn.LayerNorm(embed_dims[-1])
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.head = nn.Linear(embed_dims[-1], num_classes)

    def forward(self, x):
        x = self.patch_embed(x)
        
        for stage in self.stages:
            x = stage(x)
            
        x = self.pool(x)
        x = x.flatten(1)
        x = self.norm(x)
        x = self.head(x)
        return x

def create_fast_vit(num_classes=1000, pretrained=False):
    model = FastViT(
        image_size=224,
        in_channels=3,
        num_classes=num_classes,
        embed_dims=[64, 128, 256, 512],
        depths=[2, 2, 6, 2],
        num_heads=[2, 4, 8, 16],
        reduction_ratio=8
    )
    return model 