from torch import nn
import timm
import torch
import torch.nn.functional as F

class ComplexityEstimator(nn.Module):
    """图像复杂度估计器"""
    def __init__(self, in_channels=3):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, 16, 3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d(1)
        )
        self.fc = nn.Linear(16, 1)
    
    def forward(self, x):
        feat = self.conv(x).squeeze(-1).squeeze(-1)
        return torch.sigmoid(self.fc(feat))

class AdaptiveVisionTransformer(nn.Module):
    """Adaptive Vision Transformer for transfer learning.
    
    Args:
        model_name (str): Name of the pretrained ViT model from timm
        num_classes (int): Number of classes for the classification task
        pretrained (bool): Whether to use pretrained weights
        freeze_backbone (bool): Whether to freeze the backbone during training
        min_layers (int): Minimum number of transformer layers to use
        adaptation_threshold (float): Threshold for layer adaptation
    """
    def __init__(
        self,
        model_name: str = "vit_base_patch16_224",
        num_classes: int = 4,
        pretrained: bool = True,
        freeze_backbone: bool = False,
        min_layers: int = 4,
        adaptation_threshold: float = 0.5
    ):
        super().__init__()
        
        # 加载预训练的 ViT 模型
        self.backbone = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=num_classes,
        )
        
        # 添加复杂度估计器
        self.complexity_estimator = ComplexityEstimator(in_channels=3)
        
        # 获取模型配置
        self.num_layers = len(self.backbone.blocks)
        self.min_layers = min_layers
        self.adaptation_threshold = adaptation_threshold
        
        # 获取最后一层的输入维度
        if hasattr(self.backbone, 'head'):
            in_features = self.backbone.head.in_features
            # 使用自适应分类头
            self.backbone.head = nn.Sequential(
                nn.LayerNorm(in_features),
                nn.Dropout(0.1),
                nn.Linear(in_features, in_features // 2),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(in_features // 2, num_classes)
            )
        
        # 是否冻结主干网络
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False
            # 解冻分类头和复杂度估计器
            for param in self.backbone.head.parameters():
                param.requires_grad = True
            for param in self.complexity_estimator.parameters():
                param.requires_grad = True
    
    def get_adaptive_layers(self, complexity_score):
        """根据复杂度分数确定使用的层数"""
        if complexity_score > self.adaptation_threshold:
            # 对于复杂的图像使用更多层
            num_layers = self.num_layers
        else:
            # 对于简单的图像使用较少层
            num_layers = max(
                self.min_layers,
                int(self.num_layers * complexity_score)
            )
        return num_layers
    
    def forward_features(self, x):
        """自适应特征提取"""
        # 获取图像复杂度
        complexity_score = self.complexity_estimator(x)
        
        # 确定使用的层数
        num_layers = self.get_adaptive_layers(complexity_score.mean())
        
        # Patch embedding
        x = self.backbone.patch_embed(x)
        cls_token = self.backbone.cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        x = self.backbone.pos_drop(x + self.backbone.pos_embed)
        
        # 动态使用transformer块
        for i in range(num_layers):
            x = self.backbone.blocks[i](x)
        
        x = self.backbone.norm(x)
        return x[:, 0], complexity_score
    
    def forward(self, x):
        """前向传播"""
        features, complexity_score = self.forward_features(x)
        logits = self.backbone.head(features)
        
        if self.training:
            return logits, complexity_score
        return logits

class AdaptiveLoss(nn.Module):
    """自适应损失函数"""
    def __init__(self, base_criterion=nn.CrossEntropyLoss(), complexity_weight=0.1):
        super().__init__()
        self.base_criterion = base_criterion
        self.complexity_weight = complexity_weight
    
    def forward(self, logits, targets, complexity_score):
        # 基础分类损失
        base_loss = self.base_criterion(logits, targets)
        
        # 复杂度正则化损失：鼓励模型在可能的情况下使用更少的层
        complexity_loss = torch.mean(complexity_score)
        
        # 总损失
        total_loss = base_loss + self.complexity_weight * complexity_loss
        return total_loss

def create_adaptive_vit(
    model_name: str = "vit_base_patch16_224",
    num_classes: int = 4,
    pretrained: bool = True,
    **kwargs
):
    """创建自适应ViT模型的工厂函数"""
    model = AdaptiveVisionTransformer(
        model_name=model_name,
        num_classes=num_classes,
        pretrained=pretrained,
        **kwargs
    )
    return model 