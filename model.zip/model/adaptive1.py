from torch import nn
import timm
import torch
import torch.nn.functional as F

class AdaptiveVisionTransformer(nn.Module):
    """Adaptive Vision Transformer（消融复杂度估计器）
    仅使用固定层数，不根据复杂度自适应。
    """
    def __init__(
        self,
        model_name: str = "vit_base_patch16_224",
        num_classes: int = 4,
        pretrained: bool = True,
        freeze_backbone: bool = False,
        min_layers: int = 4,
        adaptation_threshold: float = 0.5
    ):
        super().__init__()
        self.backbone = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=num_classes,
        )
        self.num_layers = len(self.backbone.blocks)
        self.min_layers = min_layers
        self.adaptation_threshold = adaptation_threshold
        if hasattr(self.backbone, 'head'):
            in_features = self.backbone.head.in_features
            self.backbone.head = nn.Sequential(
                nn.LayerNorm(in_features),
                nn.Dropout(0.1),
                nn.Linear(in_features, in_features // 2),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(in_features // 2, num_classes)
            )
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False
            for param in self.backbone.head.parameters():
                param.requires_grad = True
    def get_adaptive_layers(self):
        # 不使用复杂度估计器，直接用全部层
        return self.num_layers
    def forward_features(self, x):
        num_layers = self.get_adaptive_layers()
        x = self.backbone.patch_embed(x)
        cls_token = self.backbone.cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        x = self.backbone.pos_drop(x + self.backbone.pos_embed)
        for i in range(num_layers):
            x = self.backbone.blocks[i](x)
        x = self.backbone.norm(x)
        return x[:, 0]
    def forward(self, x):
        features = self.forward_features(x)
        logits = self.backbone.head(features)
        return logits

class AdaptiveLoss(nn.Module):
    """自适应损失函数（结构未变，复杂度损失项恒为0）"""
    def __init__(self, base_criterion=nn.CrossEntropyLoss(), complexity_weight=0.1):
        super().__init__()
        self.base_criterion = base_criterion
        self.complexity_weight = complexity_weight
    def forward(self, logits, targets, complexity_score=None):
        base_loss = self.base_criterion(logits, targets)
        complexity_loss = 0.0
        total_loss = base_loss + self.complexity_weight * complexity_loss
        return total_loss

def create_adaptive_vit(
    model_name: str = "vit_base_patch16_224",
    num_classes: int = 4,
    pretrained: bool = True,
    **kwargs
):
    model = AdaptiveVisionTransformer(
        model_name=model_name,
        num_classes=num_classes,
        pretrained=pretrained,
        **kwargs
    )
    return model