import torch
import torch.nn as nn
import timm
import torch.nn.functional as F
from einops import rearrange

class TokenSelector(nn.Module):
    """令牌选择器模块，用于动态选择重要的令牌"""
    def __init__(self, dim, ratio=0.75):
        super().__init__()
        self.ratio = ratio  # 保留的令牌比例
        
        # 令牌重要性预测网络
        self.token_score = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, dim // 4),
            nn.GELU(),
            nn.Linear(dim // 4, 1)
        )
    
    def forward(self, x):
        # 输入x的形状: [B, N, C]，其中B是批量大小，N是令牌数量，C是特征维度
        B, N, C = x.shape
        
        # 分离类别令牌和补丁令牌
        cls_token, patch_tokens = x[:, 0:1], x[:, 1:]
        
        # 计算每个补丁令牌的重要性分数
        scores = self.token_score(patch_tokens).squeeze(-1)  # [B, N-1]
        
        # 计算要保留的令牌数量
        keep_num = max(1, int((N - 1) * self.ratio))
        
        # 选择得分最高的令牌
        _, indices = torch.topk(scores, keep_num, dim=1)  # [B, keep_num]
        indices = indices.sort(dim=1)[0]  # 排序以保持空间顺序
        
        # 创建批量索引
        batch_indices = torch.arange(B, device=x.device).unsqueeze(-1).expand(-1, keep_num)
        
        # 收集保留的令牌
        selected_tokens = patch_tokens[batch_indices, indices]  # [B, keep_num, C]
        
        # 与类别令牌合并
        x = torch.cat([cls_token, selected_tokens], dim=1)  # [B, keep_num+1, C]
        
        # 创建稀疏化掩码用于可视化（训练时）
        if self.training:
            mask = torch.zeros(B, N-1, device=x.device)
            mask[batch_indices, indices] = 1.0
            return x, mask
        
        return x

class DynamicViTBase(nn.Module):
    """基于动态令牌稀疏化的Vision Transformer
    
    Args:
        model_name (str): 预训练ViT模型名称
        num_classes (int): 分类任务的类别数
        pretrained (bool): 是否使用预训练权重
        sparsity_thresholds (list): 各阶段的稀疏度阈值列表，表示保留的令牌比例
    """
    def __init__(
        self,
        model_name: str = "vit_base_patch16_224",
        num_classes: int = 4,
        pretrained: bool = True,
        sparsity_thresholds: list = [1.0, 0.8, 0.6]  # 三个阶段的稀疏度阈值
    ):
        super().__init__()
        
        # 加载预训练的ViT模型
        self.backbone = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=0  # 移除分类头
        )
        
        # 获取模型配置
        self.num_layers = len(self.backbone.blocks)
        self.feature_dim = self.backbone.num_features
        
        # 确保稀疏度阈值列表长度合适
        assert len(sparsity_thresholds) <= self.num_layers, \
            f"稀疏度阈值列表长度({len(sparsity_thresholds)})不能大于Transformer层数({self.num_layers})"
        
        # 计算每个选择器应用的层索引
        self.selector_indices = []
        if len(sparsity_thresholds) > 1:
            interval = self.num_layers // (len(sparsity_thresholds) - 1)
            self.selector_indices = [i * interval for i in range(len(sparsity_thresholds) - 1)]
        
        # 创建令牌选择器
        self.token_selectors = nn.ModuleList([
            TokenSelector(dim=self.feature_dim, ratio=ratio)
            for ratio in sparsity_thresholds[:-1]  # 最后一个阈值不需要选择器
        ])
        
        # 分类头
        self.head = nn.Sequential(
            nn.LayerNorm(self.feature_dim),
            nn.Dropout(0.1),
            nn.Linear(self.feature_dim, num_classes)
        )
    
    def forward_features(self, x):
        """特征提取过程"""
        # Patch embedding
        x = self.backbone.patch_embed(x)
        cls_token = self.backbone.cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        x = self.backbone.pos_drop(x + self.backbone.pos_embed)
        
        # 用于存储每个选择器的掩码（用于可视化）
        masks = []
        
        # 通过Transformer块
        for i, block in enumerate(self.backbone.blocks):
            # 应用Transformer块
            x = block(x)
            
            # 如果当前层需要应用令牌选择器
            if i in self.selector_indices:
                selector_idx = self.selector_indices.index(i)
                if self.training:
                    x, mask = self.token_selectors[selector_idx](x)
                    masks.append(mask)
                else:
                    x = self.token_selectors[selector_idx](x)
        
        # 应用最后的层归一化
        x = self.backbone.norm(x)
        
        # 返回[CLS]令牌的特征
        if self.training:
            return x[:, 0], masks
        return x[:, 0]
    
    def forward(self, x):
        """前向传播"""
        if self.training:
            features, masks = self.forward_features(x)
            logits = self.head(features)
            return logits, masks
        else:
            features = self.forward_features(x)
            logits = self.head(features)
            return logits

class DynamicViTLoss(nn.Module):
    """动态ViT的损失函数，包含分类损失和稀疏化正则化"""
    def __init__(self, base_criterion=nn.CrossEntropyLoss(), sparsity_weight=0.01):
        super().__init__()
        self.base_criterion = base_criterion
        self.sparsity_weight = sparsity_weight
    
    def forward(self, logits, targets, masks=None):
        # 基础分类损失
        base_loss = self.base_criterion(logits, targets)
        
        # 如果没有提供掩码（评估模式），则只返回基础损失
        if masks is None:
            return base_loss
        
        # 稀疏化正则化损失：鼓励相邻选择器之间的一致性
        sparsity_loss = 0.0
        if len(masks) > 1:
            for i in range(len(masks) - 1):
                # 计算相邻掩码之间的一致性损失
                consistency = F.mse_loss(masks[i], masks[i+1])
                sparsity_loss += consistency
            
            sparsity_loss /= (len(masks) - 1)  # 取平均
        
        # 总损失
        total_loss = base_loss + self.sparsity_weight * sparsity_loss
        return total_loss

def create_dynamic_vit_base(
    model_name: str = "vit_base_patch16_224",
    num_classes: int = 4,
    pretrained: bool = True,
    sparsity_thresholds: list = [1.0, 0.8, 0.6],
    **kwargs
):
    """创建动态ViT模型的工厂函数"""
    model = DynamicViTBase(
        model_name=model_name,
        num_classes=num_classes,
        pretrained=pretrained,
        sparsity_thresholds=sparsity_thresholds,
        **kwargs
    )
    return model