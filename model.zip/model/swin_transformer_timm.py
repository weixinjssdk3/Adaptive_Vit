import torch
import torch.nn as nn
import timm
import os
import time
import shutil
from pathlib import Path
from huggingface_hub.utils import logging
from requests.exceptions import ChunkedEncodingError, ConnectionError, Timeout

logger = logging.get_logger(__name__)

# 定义缓存目录
CACHE_DIR = os.path.expanduser("~/.cache/torch/hub/checkpoints")
os.makedirs(CACHE_DIR, exist_ok=True)

def download_with_retry(url, filename, max_retries=3):
    """
    带有重试机制的文件下载函数
    """
    import urllib.request
    
    for attempt in range(max_retries):
        try:
            logger.info(f"尝试下载 {url} (尝试 {attempt+1}/{max_retries})")
            urllib.request.urlretrieve(url, filename)
            logger.info(f"下载成功: {filename}")
            return True
        except (ChunkedEncodingError, ConnectionError, Timeout, urllib.error.URLError) as e:
            logger.warning(f"下载出错: {e}")
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # 指数退避策略
                logger.info(f"等待 {wait_time} 秒后重试...")
                time.sleep(wait_time)
            else:
                logger.warning(f"达到最大重试次数，下载失败: {url}")
                return False

class SwinTransformerWrapper(nn.Module):
    """
    包装timm库中的Swin Transformer模型
    """
    def __init__(self, model_name, num_classes=1000, pretrained=False, max_retries=3, local_pretrained_path=None):
        super().__init__()
        
        # 如果提供了本地预训练权重路径，则使用本地权重
        if local_pretrained_path and os.path.exists(local_pretrained_path):
            logger.info(f"加载本地预训练权重: {local_pretrained_path}")
            self.model = timm.create_model(
                model_name,
                pretrained=False,
                num_classes=num_classes
            )
            # 加载本地权重
            try:
                checkpoint = torch.load(local_pretrained_path, map_location='cpu')
                if 'model' in checkpoint:
                    self.model.load_state_dict(checkpoint['model'], strict=False)
                else:
                    self.model.load_state_dict(checkpoint, strict=False)
                logger.info("本地预训练权重加载成功")
                return
            except Exception as e:
                logger.warning(f"加载本地预训练权重失败: {e}，将尝试从网络加载")
        
        # 检查是否有缓存的预训练权重
        model_filename = f"{model_name}.pth"
        cached_file = os.path.join(CACHE_DIR, model_filename)
        
        # 如果需要从网络下载预训练权重
        if pretrained:
            # 如果缓存文件存在，直接加载
            if os.path.exists(cached_file):
                logger.info(f"使用缓存的预训练权重: {cached_file}")
                try:
                    self.model = timm.create_model(
                        model_name,
                        pretrained=False,
                        num_classes=num_classes
                    )
                    checkpoint = torch.load(cached_file, map_location='cpu')
                    self.model.load_state_dict(checkpoint, strict=False)
                    logger.info("缓存预训练权重加载成功")
                    return
                except Exception as e:
                    logger.warning(f"加载缓存预训练权重失败: {e}，将尝试重新下载")
                    # 删除可能损坏的缓存文件
                    try:
                        os.remove(cached_file)
                    except:
                        pass
            
            # 尝试从网络加载预训练权重
            for attempt in range(max_retries):
                try:
                    logger.info(f"尝试加载预训练权重 (尝试 {attempt+1}/{max_retries})")
                    # 创建一个临时目录用于下载
                    temp_dir = os.path.join(CACHE_DIR, "temp")
                    os.makedirs(temp_dir, exist_ok=True)
                    temp_file = os.path.join(temp_dir, model_filename)
                    
                    # 使用预训练=False创建模型，然后手动下载权重
                    self.model = timm.create_model(
                        model_name,
                        pretrained=False,
                        num_classes=num_classes
                    )
                    
                    # 获取预训练权重URL
                    pretrained_url = timm.models.get_pretrained_cfg(model_name).url
                    if pretrained_url and download_with_retry(pretrained_url, temp_file, max_retries):
                        # 下载成功，移动到缓存目录
                        shutil.move(temp_file, cached_file)
                        # 加载权重
                        checkpoint = torch.load(cached_file, map_location='cpu')
                        self.model.load_state_dict(checkpoint, strict=False)
                        logger.info("预训练权重下载并加载成功")
                        break
                    else:
                        # 如果无法获取URL或下载失败，尝试使用timm内置方法
                        self.model = timm.create_model(
                            model_name,
                            pretrained=True,
                            num_classes=num_classes
                        )
                        logger.info("使用timm内置方法加载预训练权重成功")
                        break
                except (ChunkedEncodingError, ConnectionError, Timeout) as e:
                    logger.warning(f"下载预训练权重时出错: {e}")
                    if attempt < max_retries - 1:
                        wait_time = 2 ** attempt  # 指数退避策略
                        logger.info(f"等待 {wait_time} 秒后重试...")
                        time.sleep(wait_time)
                    else:
                        logger.warning("达到最大重试次数，使用随机初始化的模型")
                        self.model = timm.create_model(
                            model_name,
                            pretrained=False,
                            num_classes=num_classes
                        )
                finally:
                    # 清理临时目录
                    if os.path.exists(temp_dir):
                        shutil.rmtree(temp_dir, ignore_errors=True)
        else:
            # 不使用预训练权重
            self.model = timm.create_model(
                model_name,
                pretrained=False,
                num_classes=num_classes
            )
    
    def forward(self, x):
        return self.model(x)

def create_swin_transformer_small(num_classes=1000, pretrained=False, max_retries=3, local_pretrained_path=None):
    """
    创建Swin Transformer Small模型
    
    Args:
        num_classes: 分类类别数
        pretrained: 是否加载预训练权重
        max_retries: 下载预训练权重的最大重试次数
        local_pretrained_path: 本地预训练权重路径，如果提供则优先使用
    
    Returns:
        SwinTransformerWrapper: 包装后的Swin Transformer Small模型
    """
    return SwinTransformerWrapper(
        model_name='swin_small_patch4_window7_224',
        num_classes=num_classes,
        pretrained=pretrained,
        max_retries=max_retries,
        local_pretrained_path=local_pretrained_path
    )

def create_swin_transformer_base(num_classes=1000, pretrained=False, max_retries=3, local_pretrained_path=None):
    """
    创建Swin Transformer Base模型
    
    Args:
        num_classes: 分类类别数
        pretrained: 是否加载预训练权重
        max_retries: 下载预训练权重的最大重试次数
        local_pretrained_path: 本地预训练权重路径，如果提供则优先使用
    
    Returns:
        SwinTransformerWrapper: 包装后的Swin Transformer Base模型
    """
    return SwinTransformerWrapper(
        model_name='swin_base_patch4_window7_224',
        num_classes=num_classes,
        pretrained=pretrained,
        max_retries=max_retries,
        local_pretrained_path=local_pretrained_path
    )