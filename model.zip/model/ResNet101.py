import torch
import torch.nn as nn
import timm

class Bottleneck(nn.Module):
    # 指定扩张因子为4，主分支的卷积核个数最后一层会变为第一层的四倍
    expansion = 4

    def __init__(self, in_channel, out_channel, stride=1, downsample=None):
        super(Bottleneck, self).__init__()
        # 定义第一个1*1的卷积层，用于压缩通道数
        self.conv1 = nn.Conv2d(in_channels=in_channel, out_channels=out_channel, kernel_size=1, stride=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channel)
        # 定义第二个3*3的卷积层
        self.conv2 = nn.Conv2d(in_channels=out_channel, out_channels=out_channel, kernel_size=3, stride=stride, bias=False, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channel)
        # 定义第三个1*1的卷积层，用于恢复通道数
        self.conv3 = nn.Conv2d(in_channels=out_channel, out_channels=out_channel*self.expansion, kernel_size=1, stride=1, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channel*self.expansion)
        self.relu = nn.ReLU(inplace=True)
        # 下采样层，如果输入和输出的尺寸不匹配，那么会对它进行下采样
        self.downsample = downsample

    def forward(self, x):
        identity = x  # 保存输入的数据，便于进行残差连接
        if self.downsample is not None:
            identity = self.downsample(x)

        out = self.conv1(x)  # 第一个卷积改变通道数的大小，通道数的压缩
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)  # 第二个卷积核大小为3*3
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)  # 第三个卷积将通道数恢复
        out = self.bn3(out)

        out += identity  # 将主分支与捷径分支相加
        out = self.relu(out)

        return out  # 返回输出
    
class ResNet101(nn.Module):
    def __init__(self, num_classes=1000, include_top=True):
        super(ResNet101, self).__init__()
        self.include_top = include_top  # 是否包含分类头
        self.in_channel = 64
        
        # 定义第一个卷积层，输入通道数为3（RGB三通道），将图像大小减半
        self.conv1 = nn.Conv2d(3, self.in_channel, kernel_size=7, stride=2, bias=False, padding=3)
        self.bn1 = nn.BatchNorm2d(self.in_channel)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 最大池化，进一步减小特征图尺寸
        
        # ResNet101的四个阶段，分别包含3、4、23、3个Bottleneck模块
        self.layer1 = self._make_layer(Bottleneck, 64, 3)
        self.layer2 = self._make_layer(Bottleneck, 128, 4, stride=2)
        self.layer3 = self._make_layer(Bottleneck, 256, 23, stride=2)
        self.layer4 = self._make_layer(Bottleneck, 512, 3, stride=2)
        
        if self.include_top:
            self.avgpool = nn.AdaptiveAvgPool2d((1, 1))  # 自适应平均池化，输出大小为1*1
            self.fc = nn.Linear(512 * Bottleneck.expansion, num_classes)  # 全连接层，用于分类
        
        # 初始化卷积层的权重
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                # 使用kaiming初始化
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def _make_layer(self, block, channel, block_num, stride=1):
        # 创建一个残差层
        # block: 残差块类型（Bottleneck）
        # channel: 残差结构中第一个卷积层的输出通道数
        # block_num: 该层包含多少个残差结构
        # stride: 步长，用于下采样
        
        downsample = None
        # 如果步长不为1或者输入通道数不等于残差块的输出通道数，则需要进行下采样
        if stride != 1 or self.in_channel != channel * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.in_channel, channel * block.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(channel * block.expansion)
            )
        
        layers = []  # 定义一个空列表，用于存储残差结构
        # 添加第一个残差块，可能需要下采样
        layers.append(block(
            self.in_channel,
            channel,
            downsample=downsample,
            stride=stride
        ))
        
        self.in_channel = channel * block.expansion  # 更新输入通道数
        
        # 添加剩余的残差块
        for _ in range(1, block_num):
            layers.append(block(self.in_channel, channel))

        return nn.Sequential(*layers)  # 将一系列的残差结构组合在一起
    
    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)  # 通过3*3的最大池化
        
        # 依次通过四个残差层
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        if self.include_top:
            x = self.avgpool(x)
            x = torch.flatten(x, 1)  # 展平特征图
            x = self.fc(x)  # 全连接层分类

        return x  # 返回输出结果

def create_resnet101(num_classes=1000, include_top=True, pretrained=False):
    """
    创建ResNet101模型，使用timm库加载预训练的ResNet101
    
    Args:
        num_classes (int): 分类类别数，默认为1000
        include_top (bool): 是否包含顶层分类器，默认为True
        pretrained (bool): 是否加载预训练权重，默认为False
        
    Returns:
        nn.Module: 返回ResNet101模型实例
    """
    # 使用timm库加载预训练的ResNet101模型
    if pretrained:
        # 加载预训练模型
        model = timm.create_model('resnet101', pretrained=True)
        
        # 如果需要修改分类头
        if num_classes != 1000:
            # 获取最后一层全连接层的输入特征数
            in_features = model.fc.in_features
            # 替换分类头
            model.fc = nn.Linear(in_features, num_classes)
        
        # 如果不需要包含顶层分类器
        if not include_top:
            # 移除最后的全连接层，保留特征提取部分
            model.fc = nn.Identity()
    else:
        # 不使用预训练权重，使用我们自己定义的ResNet101
        model = ResNet101(num_classes=num_classes, include_top=include_top)
    
    return model