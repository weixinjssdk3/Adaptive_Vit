from torch import nn
import timm
import torch
import torch.nn.functional as F
from einops import rearrange

class ComplexityEstimator(nn.Module):
    """图像复杂度估计器"""
    def __init__(self, in_channels=3):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, 16, 3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d(1)
        )
        self.fc = nn.Linear(16, 1)
    
    def forward(self, x):
        feat = self.conv(x).squeeze(-1).squeeze(-1)
        return torch.sigmoid(self.fc(feat))

class CrossModalAttention(nn.Module):
    """多模态交叉注意力模块"""
    def __init__(self, dim, num_heads=8, qkv_bias=False, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5

        # 为每个模态创建独立的投影
        self.q_proj = nn.Linear(dim, dim, bias=qkv_bias)
        self.k_proj = nn.Linear(dim, dim, bias=qkv_bias)
        self.v_proj = nn.Linear(dim, dim, bias=qkv_bias)
        
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x1, x2):
        B, N1, C = x1.shape
        _, N2, _ = x2.shape

        # 多头投影
        q = rearrange(self.q_proj(x1), 'b n (h d) -> b h n d', h=self.num_heads)
        k = rearrange(self.k_proj(x2), 'b n (h d) -> b h n d', h=self.num_heads)
        v = rearrange(self.v_proj(x2), 'b n (h d) -> b h n d', h=self.num_heads)

        # 注意力计算
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        # 输出投影
        x = (attn @ v).transpose(1, 2).reshape(B, N1, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x

class MultimodalAdaptiveViT(nn.Module):
    """多模态自适应 Vision Transformer"""
    def __init__(
        self,
        model_name: str = "vit_base_patch16_224",
        num_classes: int = 4,
        pretrained: bool = True,
        freeze_backbone: bool = False,
        min_layers: int = 4,
        adaptation_threshold: float = 0.5,
        modal_dim: int = 256  # 第二模态的特征维度
    ):
        super().__init__()
        
        # 加载预训练的 ViT 模型
        self.backbone = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=0  # 移除分类头
        )
        
        # 获取模型配置
        self.num_layers = len(self.backbone.blocks)
        self.min_layers = min_layers
        self.adaptation_threshold = adaptation_threshold
        self.modal_dim = modal_dim
        
        # 特征维度
        self.feature_dim = self.backbone.num_features
        
        # 添加复杂度估计器
        self.complexity_estimator = ComplexityEstimator(in_channels=3)
        
        # 第二模态的特征编码器
        self.modal_encoder = nn.Sequential(
            nn.Linear(modal_dim, self.feature_dim),
            nn.LayerNorm(self.feature_dim),
            nn.GELU()
        )
        
        # 从图像特征生成第二模态特征的模块（用于单模态情况）
        self.feature_generator = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(3, modal_dim),
            nn.GELU()
        )
        
        # 交叉注意力模块
        self.cross_attn = CrossModalAttention(
            dim=self.feature_dim,
            num_heads=8
        )
        
        # 分类头
        self.head = nn.Sequential(
            nn.LayerNorm(self.feature_dim),
            nn.Dropout(0.1),
            nn.Linear(self.feature_dim, self.feature_dim // 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(self.feature_dim // 2, num_classes)
        )
        
        # 是否冻结主干网络
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False
            
            # 解冻需要训练的部分
            for module in [self.complexity_estimator, self.modal_encoder, 
                         self.cross_attn, self.head, self.feature_generator]:
                for param in module.parameters():
                    param.requires_grad = True
    
    def get_adaptive_layers(self, complexity_score):
        """根据复杂度分数确定使用的层数"""
        if complexity_score > self.adaptation_threshold:
            num_layers = self.num_layers
        else:
            num_layers = max(
                self.min_layers,
                int(self.num_layers * complexity_score)
            )
        return num_layers
    
    def forward_features(self, x, modal_features=None):
        """自适应特征提取"""
        # 获取图像复杂度
        complexity_score = self.complexity_estimator(x)
        
        # 如果没有提供第二模态特征，则从图像生成
        if modal_features is None:
            modal_features = self.feature_generator(x)
        
        # 确定使用的层数
        num_layers = self.get_adaptive_layers(complexity_score.mean())
        
        # Patch embedding
        x = self.backbone.patch_embed(x)
        cls_token = self.backbone.cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        x = self.backbone.pos_drop(x + self.backbone.pos_embed)
        
        # 动态使用transformer块
        for i in range(num_layers):
            x = self.backbone.blocks[i](x)
        
        x = self.backbone.norm(x)
        
        # 编码第二模态特征
        modal_feat = self.modal_encoder(modal_features)
        modal_feat = modal_feat.unsqueeze(1)  # [B, 1, C]
        
        # 交叉注意力融合
        x = self.cross_attn(x, modal_feat)
        
        return x[:, 0], complexity_score
    
    def forward(self, x, modal_features=None):
        """前向传播
        Args:
            x: 图像输入 [B, C, H, W]
            modal_features: 第二模态特征 [B, D]，可选
        """
        features, complexity_score = self.forward_features(x, modal_features)
        logits = self.head(features)
        
        if self.training:
            return logits, complexity_score
        return logits

class MultimodalAdaptiveLoss(nn.Module):
    """多模态自适应损失函数"""
    def __init__(self, base_criterion=nn.CrossEntropyLoss(), complexity_weight=0.1):
        super().__init__()
        self.base_criterion = base_criterion
        self.complexity_weight = complexity_weight
    
    def forward(self, logits, targets, complexity_score):
        base_loss = self.base_criterion(logits, targets)
        complexity_loss = torch.mean(complexity_score)
        total_loss = base_loss + self.complexity_weight * complexity_loss
        return total_loss

def create_multimodal_adaptive_vit(
    model_name: str = "vit_base_patch16_224",
    num_classes: int = 4,
    pretrained: bool = True,
    **kwargs
):
    """创建多模态自适应ViT模型的工厂函数"""
    model = MultimodalAdaptiveViT(
        model_name=model_name,
        num_classes=num_classes,
        pretrained=pretrained,
        **kwargs
    )
    return model 